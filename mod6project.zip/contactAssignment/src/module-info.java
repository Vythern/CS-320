/**
 * 
 */
/**
 * @author xthun
 *
 */
module contactAssignment {
	requires org.junit.jupiter.api;
}