package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;


public class appointmentServiceTest
{
	//test appointmentService constructor
	
	//test update description
	
	//test add method
	
	//test delete method
	
	
	
	@Test
	void testCreateService()
	{
		System.out.println("Testing constructor");

		AppointmentService testService = new AppointmentService();
		assertNotNull(testService);
	}
	
	@Test
	void testUpdateDescription()
	{
		System.out.println("Testing Description update");

		AppointmentService testService = new AppointmentService();
		
		testService.addAppointment(); //input 2024, 1, 1, "badDescription", "1".  //test that it can't be in the past
		testService.addAppointment(); //input 2025, 1, 1, "badDescription", "1".  
		
		testService.updateaApointmentDescription(); //input goodDescription.  
		
		
		assertEquals(testService.getAppointment("1").getDescription(), "goodDescription");
	}
	
	@Test
	void testDelete()
	{
		System.out.println("Testing deletion");

		AppointmentService testService = new AppointmentService();
		testService.addAppointment(); //input abc, 2025, 1, 1
		testService.addAppointment(); //input def, 2025, 2, 2
		//probably I will change the order that inputs are received to be date first, description second.  
		
		testService.deleteAppointment("1");
		
		assertEquals(testService.getAppointment("2").getDescription(), "def");
		//this class uses the same sorting algorithm and list management as the already known to be working taskService.  
		//thus, I'm not rewriting the tests here for the sorting algorithm.  

	}
}