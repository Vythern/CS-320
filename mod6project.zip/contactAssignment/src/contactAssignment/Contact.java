package contactAssignment;
import java.util.Scanner;


public class Contact
{
	private String contactID = "";
	private String firstName = "";
	private String lastName = "";
	private String phoneNumber = "";
	private String address = "";
	
	
	private Boolean isInteger(String strToVerify) //method assumes that it will receive a proper string.  
	{ //no negatives in this case.  so no -xxxxxxxxx
		Boolean allDigits = true;
		for(int i = 0; i < strToVerify.length(); i++)
		{
			if(!(Character.isDigit(strToVerify.charAt(i))) )  { allDigits = false; }
		}
		
		return allDigits;
	}
	
	
	
	Contact()
	{
		//Contact ID can not be updated, so it must be initialized with the object.  
		//This is the only part that really needs any code- the rest is manipulated by the service.  
		Scanner read = new Scanner(System.in);
		
		System.out.println("Empty contact created, input a unique ID, 1-10 numbers long");
		
		Boolean idFound = false;
		while(!idFound)
		{
			contactID = read.nextLine();
		    if(isInteger(this.contactID) && contactID.length() == 10) //if a 1-10 digit number
		    {
		        idFound = true;
	        }
	        else 
		    {
	        	System.out.println("Input was not a 10 digit integer, try again");
		    }
		}
		//read.close();
	}
	
	//we don't have to worry about validating the other strings, because the service will 
	//handle everything related to the validation, besides the non-updatable contactID.  
	
	
	//set methods.  Set names, number, address.  NOT ID.  ID is not updateable.  
	
	public void setFirstName(String fName) 			{ this.firstName = fName; 		   }

	public void setLastName(String lName) 			{ this.lastName = lName; 		   }

	public void setPhoneNumber(String number) 		{ this.phoneNumber = number;	   }
	
	public void setAddress(String addressParameter) { this.address = addressParameter; }
	
	//get methods- return id, names, number, address.  
	
	public String getId() 			{ return this.contactID;   }
	
	public String getFirstName() 	{ return this.firstName;   }
	
	public String getLastName() 	{ return this.lastName;    }
	
	public String getPhoneNumber() 	{ return this.phoneNumber; }
	
	public String getAddress() 		{ return this.address;     }	
}
