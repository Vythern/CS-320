package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;


public class taskServiceTest
{
	//Test the creation of the service.  
	
	//Test adding of at least 3 tasks.  
	//Check that their ids are in order.  
	
	//Check that deleting one and then adding a new one doesn't screw things up.  
	
	//Test changing description and name.  
	
	/*Inputs for the test.  
	badName
	testDescription
	testName2
	testDescription2
	testName3
	badDescription
	1
	goodName
	3
	goodDescription
	a
	d
	b
	d
	c
	d
	d
	d
	e
	d
	testNameA
	testDescriptionA
	 */
	
	
	
	@Test
	void testCreateService()
	{
		TaskService testService = new TaskService();
		assertNotNull(testService);
	}
	
	@Test
	void testUpdateNameAndDescription()
	{
		TaskService testService = new TaskService();
		
		testService.addTask();
		//input badName, testDescription
		testService.addTask();
		//input testName2, testDescription2
		testService.addTask();
		//input testName3, badDescription
		
		
		
		testService.updateTaskName();
		//input 1, goodName

		testService.updateTaskDescription();
		//input 3, goodDescription
		
		
		assertEquals(testService.getTask("1").getName(), "goodName");
		assertEquals(testService.getTask("3").getDescription(), "goodDescription");
	}
	
	@Test
	void testDelete()
	{
		TaskService testService = new TaskService();
		
		testService.addTask();
		//input a, d
		testService.addTask();
		//input b, d
		testService.addTask();
		//input c, d
		testService.addTask();
		//input d, d
		testService.addTask();
		//input e, d
		
		//index 0:  1, a, d
		//index 1:  2, b, d
		//index 2:  3, c, d
		//index 3:  4, d, d
		//index 4:  5, e, d
		
		
		
		testService.deleteTask("2");
		
		//index 0:  1, a, d
		//index 2:  3, c, d
		//index 3:  4, d, d
		//index 4:  5, e, d
				
		testService.addTask();
		//input testNameA, testDescriptionA
		
		//index 0:  1, a, d
		//index 1:  3, c, d
		//index 2:  4, d, d
		//index 3:  5, e, d
		//index 4:  2, testNameA, testDescriptionA.  
		
		
		//if sorted works:  
		//index 0:  1, a, d
		//index 4:  2, testNameA, testDescriptionA.  
		//index 1:  3, c, d
		//index 2:  4, d, d
		//index 3:  5, e, d
				
		
		testService.deleteTask("5");
		testService.deleteTask("3");
		
		//index 0:  1, a, d
		//index 4:  2, testNameA, testDescriptionA.  
		//index 2:  4, d, d
		
		assertEquals(testService.getTask("1").getID(), "1");
		assertEquals(testService.getTask("1").getName(), "a");
		assertEquals(testService.getTask("1").getDescription(), "d");
		
		assertEquals(testService.getTask("2").getID(), "2");
		assertEquals(testService.getTask("2").getName(), "testNameA");
		assertEquals(testService.getTask("2").getDescription(), "testDescriptionA");
		
		assertEquals(testService.getTask("4").getID(), "4");
		assertEquals(testService.getTask("4").getName(), "d");
		assertEquals(testService.getTask("4").getDescription(), "d");
		
		//If the input comments have been followed, then these will all pass.  
		//this means that the sorting algorithm works, adding and deleting tasks works, 
		//creating the contact service works, and the order at which you do these operations does not matter.  
		//thus, all the combinations of services that the class provides work.  
		
		
		
	}
}