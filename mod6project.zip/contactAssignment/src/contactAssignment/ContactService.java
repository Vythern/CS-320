package contactAssignment;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class ContactService
{
	
	//list of contacts.  
	//add a contact, with ID, firstName, lastName, phoneNumber, address
	//delete a contact
	//update contact by ID.  
	
	private List<Contact> serviceList;
	//ContactService is basically a list manager.  
	
	ContactService()
	{
		serviceList = new ArrayList<Contact>();
		System.out.println("Created contact service");
	}
	
	private Boolean isInteger(String strToVerify) //method assumes that it will receive a proper string.  
	{ //no negatives in this case.  so no -xxxxxxxxx
		Boolean allDigits = true;
		for(int i = 0; i < strToVerify.length(); i++)
		{
			if(!(Character.isDigit(strToVerify.charAt(i))) )  { allDigits = false; }
		}
		
		return allDigits;
	}
	
	public void addContact() //add a totally blank / new contact, and validate input.  
	{
		System.out.println("Adding new contact...");
		
		Contact newContact = new Contact();
		//Create new contact, it will get and validate a unique ID.  
		serviceList.add(newContact);
		//add contact to end of list.  We can reference the end of the list now.  
		
		Scanner readContact = new Scanner(System.in);
		
		
		String newFName   	 = "";//For each part of a contact, we get input and validate it.  
		String newLName   	 = "";
		String newNumber  	 = "";
		String newAddress 	 = "";
		
		Boolean fNameFound   = false;
		Boolean lNameFound   = false;
		Boolean numberFound  = false;
		Boolean addressFound = false;
		
		
		while(!fNameFound) //get user input for first name, last name, phone number, and address
		{
			System.out.println("Input the contact's first name:  ");
			
			
			newFName = readContact.nextLine();
			if(newFName.length() > 10 || newFName == null || newFName.length() == 0) //validate input.  
			{
				System.out.println("Names must not be null, and have 1-10 characters");
			}
			else
			{
				serviceList.get(serviceList.size() - 1).setFirstName(newFName);
				fNameFound = true;
			}
		}
		
		while(!lNameFound) //same as fName loop.  
		{
			System.out.println("Input the contact's last name:  ");
			newLName = readContact.nextLine();
			if(newLName.length() > 10 || newLName == null || newLName.length() == 0)
			{
				System.out.println("Names must not be null, and have 1-10 characters");
			}
			else
			{
				serviceList.get(serviceList.size() - 1).setLastName(newLName);
				lNameFound = true;
			}
		}
		
		while(!numberFound)
		{
			System.out.println("Input the contact's phone number:  ");
			newNumber = readContact.nextLine();
			if(newNumber.length() != 10 || isInteger(newNumber) == false)
			{
				System.out.println("Phone number must be exactly 10 digits");
			}
			else
			{
				serviceList.get(serviceList.size() - 1).setPhoneNumber(newNumber);
				numberFound = true;
			}
		}
				
		while(!addressFound) //same as name loops, but extended string length permitted.  
		{
			System.out.println("Input the contact's address:  ");
			newAddress = readContact.nextLine();
			if(newAddress.length() > 30 || newAddress == null || newAddress.length() == 0)
			{
				System.out.println("Address must not be null, and have 1-30 characters");
			}
			else
			{
				serviceList.get(serviceList.size() - 1).setAddress(newAddress);
				addressFound = true;
			}
		}

		
		//readContact.close();
	}
	
	public void addContact(Contact newContact) //alternative method, add by contact type.  
	{
		this.serviceList.add(newContact);
	}
	
	//Outputs all the contacts in the service list by ID.  
	public void listById()
	{
		for(int i = 0; i < serviceList.size(); i++)
		{
			System.out.println("ID:  " + serviceList.get(i).getId());
		}
	}
	
	//Updates a contact from the service list by ID.  
	public void deleteByID(String deleteThisID)
	{
		Boolean foundID = false;
		for(int i = 0; i < this.serviceList.size(); i++)
		{
			if(deleteThisID == this.serviceList.get(i).getId())
			{
				this.serviceList.remove(i);
				System.out.println("Deleted contact");
				foundID = true;
			}
		}
		if(!foundID) { System.out.println("Could not find contact by ID " + deleteThisID); }
	}
	
	//Updates the first name of a contact by ID.  
	public void updateFName(String ID, String newFName)
	{
		if(newFName.length() >= 1 && newFName.length() <= 10 && newFName != null)
		{
			Boolean foundID = false;
			for(int i = 0; i < this.serviceList.size(); i++)
			{
				if(ID.equals(this.serviceList.get(i).getId()))
				{
					this.serviceList.get(i).setFirstName(newFName);
					System.out.println("Updated contact first name");
					foundID = true;
				}
			}
			if(!foundID) { System.out.println("Could not find contact by ID " + ID); }
		}
		else  { System.out.println("Invalid first name for contact"); }
	}
	
	//Updates the last name of a contact by ID.  
	public void updateLName(String ID, String newLName)
	{
		if(newLName.length() >= 1 && newLName.length() <= 10 && newLName != null)
		{
			Boolean foundID = false;
			for(int i = 0; i < this.serviceList.size(); i++)
			{
				if(ID.equals(this.serviceList.get(i).getId()))
				{
					this.serviceList.get(i).setLastName(newLName);
					System.out.println("Updated contact last name");
					foundID = true;
				}
			}
			if(!foundID) { System.out.println("Could not find contact by ID " + ID); }
		}
		else  { System.out.println("Invalid last name for contact"); }
	}

	//Updates the phone number of a contact by ID.  
	public void updatePhoneNumber(String ID, String newNumber)
	{
		//really annoying having to check if things are integers in java.  
		//I ought to just write a method that does this.  
		Scanner readPhone = new Scanner(System.in);
		String newPhoneNumber = newNumber;
		Boolean isNumber = false;
		while(!isNumber)
		{
			try
			{
		        Integer.parseInt(newPhoneNumber);
		        isNumber = true;
		    }
		    catch( Exception e )
			{
		        isNumber = false;
		        System.out.println("Received non integer, try again.");
		        newPhoneNumber = readPhone.nextLine();
		    }
		}
		
		//readPhone.close();
		
		if(newPhoneNumber.length() == 10 && newPhoneNumber != null)
		{
			Boolean foundID = false;
			for(int i = 0; i < this.serviceList.size(); i++)
			{
				if(ID.equals(this.serviceList.get(i).getId()))
				{
					this.serviceList.get(i).setPhoneNumber(newPhoneNumber);
					System.out.println("Updated contact phone number");
					foundID = true;
				}
			}
			if(!foundID) { System.out.println("Could not find contact by ID " + ID); }
		}
		else  { System.out.println("Invalid phone number for contact"); }
	}
	
	//Updates the address of a contact by ID.  
	public void updateAddress(String ID, String newAddress)
	{
		if(newAddress.length() >= 1 && newAddress.length() <= 30 && newAddress != null)
		{
			Boolean foundID = false;
			for(int i = 0; i < this.serviceList.size(); i++)
			{
				if(ID.equals(this.serviceList.get(i).getId()))
				{
					this.serviceList.get(i).setAddress(newAddress);
					System.out.println("Updated contact address");
					foundID = true;
				}
			}
			if(!foundID) { System.out.println("Could not find contact by ID " + ID); }
		}
		else  { System.out.println("Invalid address for contact"); }
	}
	
	//just return the contact, can probably improve this.  
	public Contact get(int index) { return this.serviceList.get(index); }
	
}