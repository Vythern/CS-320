package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;


public class taskTest
{
	//some of these are nonsensical tests for completion purposes- that is to say, the task service manager will handle some things.  
	//eg assignment of IDs is never done by the user, but numerically and sequentially by the service manager.  
	//These two tests cover all the methods of the task class.  
	//get / set name and description, and constructor.  
	
	@Test
	void testCreateTask()
	{
		Task testTask = new Task("1","testName","testDescription");
		
		
		assertEquals("1", testTask.getID());
		assertEquals("testName", testTask.getName());
		assertEquals("testDescription", testTask.getDescription());
	}
	
	@Test
	void testUpdateTask()
	{
		Task testTask = new Task("2","emanTset","backwardsDescription");
		
		testTask.setDescription("testDescription");
		testTask.setName("testName");
		
		assertEquals("2", testTask.getID());
		assertEquals("testName", testTask.getName());
		assertEquals("testDescription", testTask.getDescription());
	}
}