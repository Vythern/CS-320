package contactAssignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;


public class TaskService
{
	private List<Task> taskServiceList;
	//TaskService is basically a list manager.  
	
	TaskService()
	{
		taskServiceList = new ArrayList<Task>();
		System.out.println("Created task service");
	}
	
	public Task getTask(String ID)
	{
		String idToRead = ID;
		boolean idFound = false;
		
		for(int i = 0; i < this.taskServiceList.size(); i++)
		{
			if(idToRead.equals(this.taskServiceList.get(i).getID()))
			{
				return this.taskServiceList.get(i);
			}
		}
		if(!idFound) 
		{
			System.out.println("Id not found");
			return null;
		}
		return null;
	}
	
	public void addTask() //create a new task, and set its name, description, and ID.  
	{
		Scanner serviceReader = new Scanner(System.in);		

		String taskID = "";
		String taskName = "";
		String taskDescription = "";
		
		System.out.println("Input the task's name:  ");		
		taskName = serviceReader.nextLine();
		
		System.out.println("Input the task's description:  ");
		taskDescription = serviceReader.nextLine();

		
		//sort the list after deleting
		//this way, the list is always in ascending order in terms of ids.  1,2,3,4, or 2, 6, 7.  
		//check the integer value of each element of the list's ID.  
		//If we find that the element n is not also occupied by an ID n
		//set the new task's id to n.  
		int missingInt = 1;

		for(int i = 0; i < this.taskServiceList.size(); i++)
		{
			if(i == (this.taskServiceList.size() - 1))
			{
				//this might cause errors?  Testing will reveal.  
				taskID = String.valueOf(this.taskServiceList.size() + 1);
				//don't have to set i to exit loop since this is always the last possible int.  
			}
			System.out.println("Important shit:  " + this.taskServiceList.get(i).getID());
			if(!(Integer.valueOf(this.taskServiceList.get(i).getID()) != missingInt))
			{
				missingInt++;
			}
			else 
			{
				i = this.taskServiceList.size();
				//break from loop if we find an unoccupied space, do not continue searching for missingInt.  
			}
		}
		taskID = String.valueOf(missingInt); 	
		
		

		
		Task newTask = new Task(taskID, taskName, taskDescription);
		
		this.taskServiceList.add(newTask);
		this.sortTasksByID();
	}

	public void updateTaskName()
	{
		Scanner serviceReader = new Scanner(System.in);		

		System.out.println("Which task (by ID) would you like to update?");
		String idToRead = serviceReader.nextLine();
		
		boolean idFound = false;
		
		for(int i = 0; i < this.taskServiceList.size(); i++)
		{
			if(idToRead.equals(this.taskServiceList.get(i).getID()))
			{
				idFound = true;
				System.out.println("What should the new name be?");
				String nameInput = serviceReader.nextLine();
				//if(nameInput) is a valid name.  
				this.taskServiceList.get(i).setName(nameInput);
			}
		}
		if(!idFound) { System.out.println("Id not found"); }
	}
	
	public void updateTaskDescription()
	{
		Scanner serviceReader = new Scanner(System.in);		

		System.out.println("Which task (by ID) would you like to update?");
		String idToRead = serviceReader.nextLine();
		
		boolean idFound = false;
		
		for(int i = 0; i < this.taskServiceList.size(); i++)
		{
			if(idToRead.equals(this.taskServiceList.get(i).getID()))
			{
				idFound = true;
				System.out.println("What should the new description be?");
				String descriptionInput = serviceReader.nextLine();
				//if(nameInput) is a valid name.  
				this.taskServiceList.get(i).setDescription(descriptionInput);
			}
		}
		if(!idFound) { System.out.println("Id not found"); }
	}
	
	public void deleteTask(String idToRemove)
	{
		for(int i = 0; i < this.taskServiceList.size(); i++)
		{
			if(idToRemove.equals(this.taskServiceList.get(i).getID()))
			{
				this.taskServiceList.remove(i);
			}
		}
		this.sortTasksByID();
	}

	private void sortTasksByID()
	{
		//I spent like 2 hours figuring out how clever this simple assignment's directions were
		//that is to say, there are so many ways you can create little micro-bugs
		//the worst part is that it HAS to be a string ID.  
		//It really makes you to want to run tests, and then fix it after testing.  
		//Probably there will be a journal or discussion post to talk about this in.  
		//moral of the story is, it was really annoying to write a sorting method for this class.  
        Collections.sort(this.taskServiceList, new Comparator<Task>()
        {
            public int compare(Task task1, Task task2)
            {
                String id1 = task1.getID();
                String id2 = task2.getID();

                return id1.compareTo(id2);
            }
        });
        for(int i = 0; i < this.taskServiceList.size(); i++)
        {
        	System.out.println("ID " + i + ":  " + this.taskServiceList.get(i).getID());
        }
    }
	
}