package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.time.*;
import java.time.LocalDate;
import java.util.Date;


public class appointmentTest
{
	//Test the appointment constructor
	
	//test the set methods
	
	//Test the get methods
	
	//Appointment(int newYear, int newMonth, int newDay, String newDescription, String newAppointmentID)
	
	@Test
	void testAppointment()
	{
		Appointment testAppointment = new Appointment(2024, 1, 1, "First day of 2024", "1");
		assertNotNull(testAppointment);
	}
	
	@Test
	void testgGetMethods()
	{
		Appointment testAppointment = new Appointment(2024, 1, 1, "First day of 2024", "1");	//Create appointment on jan 1st, with ID 1.  
		assertEquals(testAppointment.getAppointmentDate(), LocalDate.of(2024, 1, 1));			//Verify date
		assertEquals(testAppointment.getDescription(), "First day of 2024");					//Verify description
		assertEquals(testAppointment.getID(), "1");												//Verify ID
	}
	
	@Test
	void testSetMethods()
	{
		Appointment testAppointment = new Appointment(2023, 12, 31, "New Years Eve", "1"); //create date, 1 day before the desired day.  
		testAppointment.setDate(2024, 1, 1); //update year, month, and day.  
		testAppointment.setDescription("First day of 2024"); //update description
		
		assertEquals(testAppointment.getAppointmentDate(), LocalDate.of(2024, 1, 1)); //verify results.  
		assertEquals(testAppointment.getDescription(), "First day of 2024");
		assertEquals(testAppointment.getID(), "1");	
	}
}