package contactAssignment;

import java.time.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

//We trust the appointmentService class to do the verifying of data.  
//Data can only be sent to the appointment object via that class.  

public class Appointment
{
	private String appointmentID;	//not null, not updateable, less than 10 characters.  
	private String description;		//less than 50 characters.  Can be updateable.  

	private LocalDate appointmentDate; //date of the upcoming appointment
	
	Appointment(int newYear, int newMonth, int newDay, String newDescription, String newAppointmentID)
	{
		this.appointmentID = newAppointmentID;
		this.setDate(newYear, newMonth, newDay);		
		this.setDescription(newDescription);
	}
	
	public void setDate(int year, int month, int day) //we entrust the appointment service to handle input.  
	{ this.appointmentDate = LocalDate.of(year, month, day); }
	
	public void setDescription(String newDescription)
	{ this.description = newDescription; }
	
	
	public String getID() { return this.appointmentID; }
	
	public LocalDate getAppointmentDate() { return this.appointmentDate; }
	
	public String getDescription() { return this.description; }
}