package contactAssignment;

public class Task
{
	private String ID = ""; //max length 10 characters, not null, not updateable.  
	private String name = "";
	private String description = "";
	
	//the task service is the only thing that can create and manage the Task class.  
	//Thus, we will only ever create a task object with an ID in mind.  
	//The ids will be managed by the TaskService.  
	//Fortunately there is no stipulation that the task/service need be char/int or anything
	//So these should be simpler to implement.  Only ever create tasks through the service!  
	
	//mind that the task service manager must be "managed" properly or else these methods can be invoked in err.  
	
	public Task(String newID, String newName, String newTaskDescription) 
	{
		this.ID = newID;
		this.name = newName;
		this.description = newTaskDescription;
		System.out.println("New task created with name '" + this.name + 
							"',\nDescription:  '" + this.description + 
							"', \nID:  " + this.ID);
		//Name\nDescription\nID:  
	}
		
	public String getID() { return this.ID; }
	
	public String getName() { return this.name; }
	
	public String getDescription() { return this.description; }
	
	public void setName(String newName) { this.name = newName; }
	
	public void setDescription(String newDescription) { this.description = newDescription; }
	
}