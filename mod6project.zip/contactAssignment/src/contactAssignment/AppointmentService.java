package contactAssignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.time.*;
import java.time.LocalDate;
import java.util.Date;

public class AppointmentService
{
	private List<Appointment> appointmentServiceList;
	//AppointmentService is basically a list manager.  
	
	AppointmentService()
	{
		appointmentServiceList = new ArrayList<Appointment>();
		System.out.println("Created Appointment service");
	}
	
	public Appointment getAppointment(String ID)
	{
		String idToRead = ID;
		boolean idFound = false;
		
		for(int i = 0; i < this.appointmentServiceList.size(); i++)
		{
			if(idToRead.equals(this.appointmentServiceList.get(i).getID()))
			{
				return this.appointmentServiceList.get(i);
			}
		}
		if(!idFound) 
		{
			System.out.println("Id not found");
			return null;
		}
		return null;
	}
	
	public void addAppointment() //create a new appointment, and set its date, description, and ID.  
	{
		Scanner serviceReader = new Scanner(System.in);		

		String appointmentID = "";
		String appointmentDescription = "";

		int appointmentYear = 2024;
		int appointmentMonth = 1;
		int appointmentDay = 1;		
		
		
		boolean descriptionFound = false;
		while(!descriptionFound)
		{
			System.out.println("Input the appointment's description:  ");
			appointmentDescription = serviceReader.nextLine();
			if(!(appointmentDescription.equals(null)))
			{
				if(appointmentDescription.length() >= 1 && appointmentDescription.length() <= 50)
				{
					descriptionFound = true;
				}
			}
			if(!descriptionFound)
			{
				System.out.println("Invalid input, description must be >= 1 characters, <= 50, and not null");
			}
		}		
		
		Boolean dateFound = false;
		while(!dateFound) //try until user learns how to input things correctly.  
		{
			System.out.println("Input the Appointment's date\nType an integer, then press enter, for the year, month, and day:  ");
			Boolean validInput = true;
			if(serviceReader.hasNextInt())
			{
			    appointmentYear = serviceReader.nextInt();
			}
			else
			{
				System.out.println("Received invalid input, try again.");
				validInput = false;
			}
			if(serviceReader.hasNextInt() && validInput)
			{
			    appointmentMonth = serviceReader.nextInt();
			}
			else
			{
				if(validInput) { System.out.println("Received invalid input, try again."); } //the user does not need to be berated three times with the error message
				validInput = false;
			}
			
			if(serviceReader.hasNextInt() && validInput)
			{
			    appointmentDay = serviceReader.nextInt();
			}
			else
			{
				if(validInput) { System.out.println("Received invalid input, try again."); } //the user does not need to be berated three times with the error message
				validInput = false;
			}
			if(validInput)
			{
				LocalDate tempDate = LocalDate.of(appointmentYear, appointmentMonth, appointmentDay);
				if(tempDate.compareTo(LocalDate.now()) > 0) //if the received inputed date is after the present day:  
				{
					dateFound = true;
					//set the newAppointmentDate?  
				}
				else 
				{
					System.out.println("Appointment date can not be in the past, try again");
					validInput = false;
				}
			}
		}


		
		//sort the list after deleting
		//this way, the list is always in ascending order in terms of ids.  1,2,3,4, or 2, 6, 7.  
		//check the integer value of each element of the list's ID.  
		//If we find that the element n is not also occupied by an ID n
		//set the new Appointment's id to n.  
		int missingInt = 1;

		for(int i = 0; i < this.appointmentServiceList.size(); i++)
		{
			if(i == (this.appointmentServiceList.size() - 1))
			{
				//this might cause errors?  Testing will reveal.  
				appointmentID = String.valueOf(this.appointmentServiceList.size() + 1);
				//don't have to set i to exit loop since this is always the last possible int.  
			}
			if(!(Integer.valueOf(this.appointmentServiceList.get(i).getID()) != missingInt))
			{
				missingInt++;
			}
			else 
			{
				i = this.appointmentServiceList.size();
				//break from loop if we find an unoccupied space, do not continue searching for missingInt.  
			}
		}
		appointmentID = String.valueOf(missingInt);
		
		

		
		Appointment newAppointment = new Appointment(appointmentYear, appointmentMonth, appointmentDay, appointmentDescription, appointmentID);
		
		this.appointmentServiceList.add(newAppointment);
		this.sortAppointmentsByID();
	}
	
	public void updateaApointmentDescription()
	{
		Scanner serviceReader = new Scanner(System.in);		

		System.out.println("Which Appointment (by ID) would you like to update?");
		String idToRead = serviceReader.nextLine();
		
		boolean idFound = false;
		
		for(int i = 0; i < this.appointmentServiceList.size(); i++)
		{
			if(idToRead.equals(this.appointmentServiceList.get(i).getID()))
			{
				idFound = true;
				System.out.println("What should the new description be?");
				String descriptionInput = serviceReader.nextLine();
				//if(descriptionInput) is a valid name.  
				this.appointmentServiceList.get(i).setDescription(descriptionInput);
			}
		}
		if(!idFound) { System.out.println("Id not found"); }
	}
	
	public void deleteAppointment(String idToRemove)
	{
		for(int i = 0; i < this.appointmentServiceList.size(); i++)
		{
			if(idToRemove.equals(this.appointmentServiceList.get(i).getID()))
			{
				this.appointmentServiceList.remove(i);
			}
		}
		this.sortAppointmentsByID();
	}

	private void sortAppointmentsByID()
	{
        Collections.sort(this.appointmentServiceList, new Comparator<Appointment>()
        {
            public int compare(Appointment appointment1, Appointment appointment2)
            {
                String id1 = appointment1.getID();
                String id2 = appointment2.getID();

                return id1.compareTo(id2);
            }
        });
        for(int i = 0; i < this.appointmentServiceList.size(); i++)
        {
        	System.out.println("ID " + i + ":  " + this.appointmentServiceList.get(i).getID());
        }
    }
}
