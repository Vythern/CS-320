package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class contactTest
{
	//Check that a contact can be created.  
	//Check that it has all relevant members.  
	//Check each contact member-	
	/* ID- 				1-10 digits.  Not null.  
	 * First Name- 		1-10 characters.  Not null.  
	 * Last Name- 		1-10 characters.  Not null.  
	 * Phone Number- 	10 digits exactly.  Not null.  
	 * Address- 		1-30 characters.  Not null.  
	 */
	//Testing the contact class is easy- we just have to verify that the members of the class are properly updated upon setting them
	//If they do, then we know we can move onto the service tests.  
	
	
	@Test
	void testSetGetMethods() //Check to see that all the members of the contact exist and work.  
	{
		System.out.println("Running testSetGetMethods test");
		Contact testContact2 = new Contact();
		
		
		testContact2.setFirstName("John");
		testContact2.setLastName("Smith");
		testContact2.setPhoneNumber("1234567890");
		testContact2.setAddress("Address with < 30 characters");
		
		assertEquals(testContact2.getId(), "1000000000"); 	//There does not exist a loop where anything but a 10 digit integer reaches this point.  
															//I would make an input stream for this test but it's far easier to just type the ID each time.  
		
		//If setting has gone well, these will all pass, and we will know the get methods are working as well.  
		
		assertEquals(testContact2.getFirstName(), "John");
		assertEquals(testContact2.getLastName(), "Smith");
		assertEquals(testContact2.getPhoneNumber(), "1234567890");
		assertEquals(testContact2.getAddress(), "Address with < 30 characters");
	}
}
