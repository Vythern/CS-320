package contactAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;


public class contactServiceTest
{
	//Check that the service can be created.  
	//Check that it has all relevant members.  
	//Check each service method-	
	/* addContact()
	 * deleteContact()
	 * updateContact()
	 * 
	 * 
	 */
	
	@Test
	void testServiceCreation() //check that the contact service constructor works
	{
		System.out.println("Running service test");
		ContactService contactServiceTest = new ContactService();
		assertNotNull(contactServiceTest);
		//Check whether the service exists.  Should not be null.  
	}
	
	@Test
	void testAddContact()
	{
		System.out.println("Running add test");
		ContactService contactServiceTest = new ContactService();

		contactServiceTest.addContact();
		
		//Through the contact service, add a contact, set the values of the contact, and then compare the contact we added to the tests.  
		//if it passes, then we know adding contacts is a success.  
		assertEquals("John", contactServiceTest.get(0).getFirstName());
		assertEquals("Smith", contactServiceTest.get(0).getLastName());
		assertEquals("1234567890", contactServiceTest.get(0).getPhoneNumber());
		assertEquals("Address with < 30 characters", contactServiceTest.get(0).getAddress());
		
	}
	
	@Test
	void testDeleteContact()
	{
		System.out.println("Running delete test");
		ContactService contactServiceTest = new ContactService();
		
		System.out.println("Adding dummy contact, type 0000000000 for id to test it");
		contactServiceTest.addContact(); //add a dummy contact to index 0.  
		
		//delete it by the id later, then check whether get(0) has the "real" contact.  
		//also tests the addContact overload with contact as a parameter.  
		Contact testContact = new Contact();
		
		testContact.setFirstName("John");
		testContact.setLastName("Smith");
		testContact.setPhoneNumber("1234567890");
		testContact.setAddress("Address with < 30 characters");
		
		contactServiceTest.addContact(testContact);
		
		contactServiceTest.deleteByID("0000000000"); //we input 0000000000, then delete by that id.  

		
		//If the dummy contact at index 0 is deleted, then these will pass.  
		assertEquals("John", contactServiceTest.get(0).getFirstName());
		assertEquals("Smith", contactServiceTest.get(0).getLastName());
		assertEquals("1234567890", contactServiceTest.get(0).getPhoneNumber());
		assertEquals("Address with < 30 characters", contactServiceTest.get(0).getAddress());
		
		
	}
	
	@Test
	void testUpdateContact()
	{
		System.out.println("Running update test");
		//start by creating a contact.  
		
		//then change the values from the original
		
		//then test against them.  
		ContactService contactServiceTest = new ContactService();
		
		Contact testContact = new Contact();
		//Give this contact id 0000000000
		
		testContact.setFirstName("nhoJ");
		testContact.setLastName("thimS");
		testContact.setPhoneNumber("0987654321");
		testContact.setAddress("Not typing that backwards");
		
		contactServiceTest.addContact(testContact);
		
		
		contactServiceTest.updateFName("0000000000", "John");
		contactServiceTest.updateLName("0000000000", "Smith");
		contactServiceTest.updatePhoneNumber("0000000000", "1234567890");
		contactServiceTest.updateAddress("0000000000", "Address with < 30 characters");

		
		//if the update methods work, then these too will pass.  
		assertEquals("John", contactServiceTest.get(0).getFirstName());
		assertEquals("Smith", contactServiceTest.get(0).getLastName());
		assertEquals("1234567890", contactServiceTest.get(0).getPhoneNumber());
		assertEquals("Address with < 30 characters", contactServiceTest.get(0).getAddress());
	}
}